# hw8 > 2023-03-01 8:32pm
https://universe.roboflow.com/object-detection/hw8-gnmlo

Provided by a Roboflow user
License: CC BY 4.0

